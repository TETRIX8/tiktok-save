TOKEN = '5328203011:AAFbHZ75XL_NAKOoZ_M-8Zc6ZkxxPbeuTfg'
admins = 1404494933
chat = -1001965151482

# Наш telegram форум https://na-sha.ru/